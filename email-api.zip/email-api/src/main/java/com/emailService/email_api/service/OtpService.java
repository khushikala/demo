package com.emailService.email_api.service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OtpService {

    private final Map<String, OtpEntry> otpStorage = new ConcurrentHashMap<>();

    private static class OtpEntry {
        String otp;
        long expiryTime;

        OtpEntry(String otp, long expiryTime) {
            this.otp = otp;
            this.expiryTime = expiryTime;
        }
    }

    public String generateOtp(String email) {
        String otp = String.valueOf(100000 + new Random().nextInt(900000));
        otpStorage.put(email, new OtpEntry(otp, System.currentTimeMillis() + 5 * 60 * 1000));
        return otp;
    }

    public boolean validateOtp(String email, String otp) {
        OtpEntry entry = otpStorage.get(email);
        if (entry == null || System.currentTimeMillis() > entry.expiryTime) {
            return false;
        }
        boolean isValid = entry.otp.equals(otp);
        if (isValid) {
            otpStorage.remove(email); // One-time use
        }
        return isValid;
    }
}
