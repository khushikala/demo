package com.emailService.email_api.service;

import com.emailService.email_api.Entity.User;
import com.emailService.email_api.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepo;

    public User findOrCreateUser(String email) {
        return userRepo.findByEmail(email).orElseGet(() ->
            userRepo.save(new User(email))
        );
    }

    public void markAsVerified(String email) {
        userRepo.findByEmail(email).ifPresent(user -> {
            user.setVerified(true);
            userRepo.save(user);
        });
    }
}
